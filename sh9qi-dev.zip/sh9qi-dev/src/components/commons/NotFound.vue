<template>
    <div>
        <nav-bar title="找不到资源"></nav-bar>
        您要访问的页面去旅行了！
    </div>
</template>
<script>
    export default {
        data(){
            return {

            }
        }
    }
</script>
<style>
    
</style>