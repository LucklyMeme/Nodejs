define( function() {
	return ( /^$|\/(?:java|ecma)script/i );
} );
