module.exports = {
    rootPath:__dirname, //项目根目录
    db_host:'127.0.0.1',//数据库ip
    db_connectionLimit:10, //连接池数量
    db_user:'root', //数据库用户名
    db_password: 'root',//数据库密码
    db_database: 'node_music', //数据库名
    web_host:'localhost', //未来服务器被访问时的外网IP
    web_port:9999, //服务器端口
}

